package Lab1;

import java.util.Scanner;

/**
 * @author abdulaziz abdullah bahamid 441016576
 */
public class PerformanceTest {


    public void linearTest(int n) {
        int loopcount = 0;
        double starttime = System.nanoTime();
        System.out.print("O(" + n + ") took.. ");
        for (int i = 0; i < n; i++) {
            loopcount++;
        }
        double endtime = System.nanoTime();;
        System.out.println(((endtime - starttime)) + " nano seconds");
        System.out.println("plus the loob counts of it is: " + loopcount + "\n");

    }

    /**
     * Test Quadratic performance O(N^2)
     *
     * @param n Size of test
     */
    public void quadraticTest(int n) {
        int loopcount = 0;
        double starttime = System.nanoTime();
        System.out.print("O(" + n + "^2) took.. ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                loopcount++;
            }
        }
        double endtime = System.nanoTime();;
        System.out.println(((endtime - starttime)) + " nano seconds");
        System.out.println("plus the loob counts of it is: " + loopcount + "\n");
    }

    /**
     * Test Cubic Performance O(N^3)
     *
     * @param n Size of test
     */
    public void cubicTest(int n) {
        int loopcount = 0;
        double starttime = System.nanoTime();
        System.out.print("O(" + n + "^3) took.. ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    loopcount++;
                }
            }
        }
        double endtime = System.nanoTime();;
        System.out.println(((endtime - starttime)) + " nano seconds");
        System.out.println("plus the loob counts of it is: " + loopcount + "\n");
    }

    /**
     * Main Method
     *
     * @param args command line parameters (optional)
     */
    public static void main(String args[]) {
        PerformanceTest p = new PerformanceTest();
        Scanner scan = new Scanner(System.in);
        System.out.println("please enter the number of N you want to test: ");
        int n = 1000;
        p.linearTest(n);
        p.quadraticTest(n);
        p.cubicTest(n);

        // call methods of object p (PerformanceTest) with
        // various sizes of N and see the performance differences.
    }
}
