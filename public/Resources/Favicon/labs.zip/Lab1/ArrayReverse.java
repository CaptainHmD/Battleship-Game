package Lab1;

import java.util.Scanner;

public class ArrayReverse {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("enter the size of the array: ");
        int size = input.nextInt();
        int[] arr = new int[size];
        
        //we will ask the user to fill the array with values
        System.out.println("please enter " + size + " numbers to fill the array.");
        for (int i = 0; i < size; i++) {
            arr[i] = input.nextInt();
        }
        //we will set a variable to know when we will reach half of the array to reverse
        int half = size/2;
        int temp= 0; //the temporary variable to help us reverse the array
        
        for (int i = 0; i < half; i++) {
            temp = arr[i];
            arr[i] = arr[(arr.length-1)-i];
            arr[(arr.length-1)-i] = temp;
        }
        
        System.out.println("the reversed array: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
