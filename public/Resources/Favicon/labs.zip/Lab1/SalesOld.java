package Lab1;

import java.util.Scanner;

public class SalesOld {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("please enter the number of sales people:");
        final int SALESPEOPLE = scan.nextInt();
        int[] sales = new int[SALESPEOPLE];
        int sum;
        
        //here we will store the id and the amount of the best salesman
        //the first index will be the id and the second will be the amount
        int[] maxSale = {0, sales[0]};
        int[] minSale = {1, sales[0]};

        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for salesperson " + (i + 1) + ": ");
            sales[i] = scan.nextInt();
            //here we will the minmum amont to the first value the user entered
            if (i == 0) minSale[1] = sales[i];
            //here we will computeand store the maximum sale and it's index
            if (maxSale[1] < sales[i]) {
                maxSale[1] = sales[i];
                maxSale[0] = i+1;
            }
            //the second condition to let us start checking the minimum value from the cecond value
            if (minSale[1] > sales[i] && i !=0) {
                minSale[1] = sales[i];
                minSale[0] = i+1;
            }
        }

        System.out.println("\nSalesperson Sales");
        System.out.println("    ");

        sum = 0;
        for (int i = 0; i < sales.length; i++) {
            System.out.println("the id of the sales man: " + (i+1) + " his sales: " + sales[i]);
            sum += sales[i];
        }
        //here will be printing the final result of the report
        System.out.println("\nTotal sales: " + sum);
        System.out.println("the average sales is: " + (sum / (double) SALESPEOPLE) + "\n");
        
        System.out.println("the perosn id with heighest sales is: " + maxSale[0]);
        System.out.println("and the amount is: " + maxSale[1] + "SR\n");
        
        System.out.println("for the person id with the least sales is: " + minSale[0]);
        System.out.println("and the amount is: " + minSale[1] + "SR");
    }
}
