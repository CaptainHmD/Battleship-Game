
package Lab1;


public class PersonTest {
    public static void main(String[] args) {
        // here we will create a person object
        //then we will test it's methods:
        Person person1 = new Person();
        System.out.println(person1);
        System.out.println("then we will set values to this person");
        person1.setName("ahmed");
        person1.setAge(25);
        person1.setHeight(1.8);
        //here we will print the to string for the object again:
        System.out.println(person1);
        
        System.out.println("");
        // here we ititlaize an object with it values inside the constructor
        Person person2 = new Person("khalid", 22, 1.75);
//        then we will print the object again in the toString method of it     
        System.out.println(person2);
    }
}
