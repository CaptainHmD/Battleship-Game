package Lab2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class HighArray {

    public long[] a;                 // ref to array a
    public int nElems;               // number of data items
    //-----------------------------------------------------------

    public HighArray(int max) // constructor
    {
        a = new long[max];                 // create the array
        nElems = 0;                        // no items yet
    }
    //-----------------------------------------------------------

    public boolean find(long searchKey) {                              // find specified value
        int j;
        for (j = 0; j < nElems; j++) // for each element,
        {
            if (a[j] == searchKey) // found item?
            {
                return true;                       // exit loop before end
            }
        }
        return false;

    }  // end find()
    //-----------------------------------------------------------

    public void insert(long value) // put element into array
    {
        a[nElems] = value;             // insert it
        nElems++;                      // increment size
    }

    public void insert(String fileName) {//read from file
        try {
            Scanner file = new Scanner(new File(fileName));
            while (file.hasNext()) {
                this.insert(file.nextLong());
            }
        } catch (FileNotFoundException e) {
            System.out.println("file was not found");
        }

    }

//-----------------------------------------------------------
    public void insertOrdered(long value) // put element into array
    {
        int j;
        for (j = 0; j < nElems; j++) // find where it goes
        {
            if (a[j] > value) // (linear search)
            {
                break;
            }
        }
        for (int k = nElems; k > j; k--) // move bigger ones up
        {
            a[k] = a[k-1];
        }
        a[j] = value;                  // insert it
        nElems++;                      // increment size
        
    }  // end insert()
    //-----------------------------------------------------------

    public boolean delete(long value) {
        int j;
        for (j = 0; j < nElems; j++) // look for it
        {
            if (value == a[j]) {
                break;
            }
        }
        if (j == nElems) // can't find it
        {
            return false;
        } else // found it
        {
            for (int k = j; k < nElems - 1; k++) // move higher ones down
            {
                a[k] = a[k + 1];
            }
            nElems--;                   // decrement size
            return true;
        }
    }  // end delete()
    //-----------------------------------------------------------

    public void display() // displays array contents
    {
        if (nElems == 0) {
            System.out.println("there no elemnts in the list");
        }
        for (int j = 0; j < nElems; j++) // for each element,
        {
            System.out.print(a[j] + " ");  // display it
        }
        System.out.println("");
    }
    //-----------------------------------------------------------

    public int binarySearch(int searchKey) {
        int left = 0, right = nElems - 1, passCount = 1;
        while (left <= right) {
            int pivot = (left + right) / 2;
            System.out.println("pass" + passCount + ": left=" + left + " right=" + right + " pivot=" + pivot);
            passCount++;

            if (a[pivot] == searchKey) {
                return pivot;       // found
            } else {
                if (a[pivot] < searchKey) {
                    left = pivot + 1;  // search right
                } else {
                    right = pivot - 1;  // search left
                }
            }
        }
        return -1;
    }

    //find the number of an elemtn occured in the array
    public int findAll(int elem) {
        int counter = 0;
        for (int i = 0; i < nElems; i++) {
            if (a[i] == elem) {
                counter++; //incremant the counter if we found the element
            }
        }
        return counter;
    }

    //delete every occurence of an element
    public int deleteAll(int elem) {
        int counter = 0;

        for (int i = 0; i < nElems; i++) {
            if (a[i] == elem) {
                delete(elem);
                counter++;
                i--;// 1 2 3 0
            }
        }
        return 0;
    }

    //find the maximum value in the array
    public long max() {
        long max = a[0];
        for (int i = 1; i < nElems; i++) {
            if (a[i] > max) {
                max = a[i];
            }
        }
        return max;
    }

    //find the index of the maximuum value
    public int maxIndex() {
        int index = 0;
        long max = a[0];
        for (int i = 1; i < nElems; i++) {
            if (a[i] > max) {
                max = a[i];
                index = i;
            }

        }
        return index;
    }

    //find the minimum value in the array
    public long min() {
        long min = a[0];
        for (int i = 1; i < nElems; i++) {
            if (a[i] < min) {
                min = a[i];
            }
        }
        return min;
    }

    //find the index of the minimuum value
    public int minIndex() {
        int index = 0;
        long min = a[0];
        for (int i = 1; i < nElems; i++) {
            if (a[i] < min) {
                min = a[i];
                index = i;
            }
        }
        return index;
    }

    public long range() {
        return (max() - min());
    }

    public long sum() {
        long sum = 0;
        for (int i = 0; i < nElems; i++) {
            sum += a[i];
        }
        return sum;
    }

    public double avg() {
        double avg = ((double) this.sum()) / nElems;
        return avg;
    }

    public double std() {
        double mean = this.avg();
        double std = 0;

        for (int i = 0; i < nElems; i++) {
            std += Math.pow(a[i] - mean, 2);
        }
        std = Math.sqrt(std / nElems);
        return std;
    }

    public long rank(int i) {
        return 0;
    }

    public boolean checkOrdered() {
        for (int i = 0; i < nElems - 1; i++) {
            if (a[i] > a[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public boolean checkUnique() {
        for (int i = 0; i < nElems; i++) {
            for (int j = i + 1; j < nElems; j++) {
                if (a[i] == a[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public void removeDuplicates() {
        for (int i = 0; i < nElems; i++) {
            for (int j = i + 1; j < nElems; j++) {
                if (a[i] == a[j]) {
                    for (int k = j; k < nElems - 1; k++) {
                        a[k] = a[k + 1];
                    }
                    j--;
                    nElems--;
                }
            }
        }
    }

    public void fillArrayRandom() {
        for (int i = 0; i < a.length; i++) {
            a[i] = (int) (Math.random() * 100) + 1;
        }
        nElems = a.length;
    }

    public int size() {
        return nElems;
    }

}  // end class HighArray
