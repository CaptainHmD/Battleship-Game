package Lab2;

import java.util.Scanner;
import java.io.FileNotFoundException;

class HighArrayApp  {

    public static void main(String[] args) throws FileNotFoundException  {
        Scanner input = new Scanner(System.in);
        
        System.out.print("enter the array size: ");
        int maxSize = input.nextInt();
        HighArray arr = new HighArray(maxSize);
        
        System.out.print("Please enter the file name: ");
        String fileName = input.next();// file name
        arr.insert(fileName);
        
        arr.insert(00);
        arr.insert(88);
        arr.insert(33);
        
        arr.display();                // display items

        int searchKey = 99;           // search for item
        if (arr.find(searchKey)) {
            System.out.println("Found " + searchKey);
        } else {
            System.out.println("Can't find " + searchKey);
        }

        arr.delete(00);               // delete 3 items
        arr.delete(55);
        arr.delete(99);

        arr.display();                // display items again
        
        arr.deleteAll(77); // delete all items that match the elemment
        
        arr.display(); //display the array
        
        System.out.println("max value is: " + arr.max());
        System.out.println("minimum value is: " + arr.min());
        System.out.println("the index of minimum is: " + arr.maxIndex());
        System.out.println("the range is: " + arr.range());
        System.out.println("the standar deviation is: " + arr.std());
        System.out.println("is the array ordered? " + arr.checkOrdered());
        System.out.println("are the elements unique? " + arr.checkUnique());
        System.out.println("before the dublicates:");
        arr.display();
        System.out.println("after removing the dublicates");
        arr.removeDuplicates();
        arr.display();
        System.out.println("we found the number 5 in: " + arr.binarySearch(5));
    }  // end main()
}  // end class HighArrayApp
