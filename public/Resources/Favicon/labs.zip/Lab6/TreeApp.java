package Lab6;

////////////////////////////////////////////////////////////////
import java.util.*;

class TreeApp {

    public static void main(String[] args) {
        int value;
        Tree theTree = new Tree();
        System.out.println("Weclome to Tree Test applications");
        theTree.insert(50);
        theTree.insert(25);
        theTree.insert(75);
        theTree.insert(12);
        theTree.insert(37);
        theTree.insert(43);


            System.out.println(theTree.height(theTree.root));
            System.out.println(theTree.nodes(theTree.root));
//        int height = theTree.height(theTree.root);
//        int nodes = theTree.nodes(theTree.root);
//        if (nodes == (Math.pow(2,height)-1) ) System.out.println("true");
        
        
        
//        theTree.insert(30);
//        theTree.insert(33);
//        theTree.insert(87);
//        theTree.insert(93);
//        theTree.insert(97);
        

//        while (true) {
//            System.out.println("Enter first letter of insert, find, delete,  traverse, max and min, Recursion performance, exit:");
//
//            Scanner in = new Scanner(System.in);
//
//            char choice = in.next().charAt(0);
//            switch (choice) {
//                case 'i':
//                    System.out.print("Enter value to insert: ");
//                    value = in.nextInt();
//                    theTree.insert(value);
//                    break;
//                case 'f':
//                    System.out.print("Enter value to find: ");
//                    value = in.nextInt();
//                    TNode found = theTree.find(value);
//                    if (found != null) {
//                        System.out.print("Found: ");
//                        System.out.println(found);
//                        System.out.print("\n");
//                    } else {
//                        System.out.print("Could not find ");
//                        System.out.print(value + '\n');
//                    }
//                    break;
//                case 'd':
//                    System.out.print("Enter value to delete: ");
//                    value = in.nextInt();
//                    boolean didDelete = theTree.delete(value);
//                    if (didDelete) {
//                        System.out.print("Deleted " + value + '\n');
//                    } else {
//                        System.out.print("Could not delete ");
//                        System.out.println(value);
//                    }
//                    break;
//                case 't':
//                    System.out.print("Enter type 1, 2 , 3 or 4: ");
//                    value = in.nextInt();
//                    theTree.traverse(value);
//                    break;
//                case 'm':
//                    System.out.println("Enter:\n"
//                            + "1 for maximum iterative\n"
//                            + "2 for minimum iterative\n"
//                            + "3 for maximum recursive\n"
//                            + "4 for minimum recursive");
//                    value = in.nextInt();
//                    theTree.maxMin(value);
//                    break;
//                case 'r':
//                    System.out.print("Enter value to find: ");
//                    value = in.nextInt();
//                    TNode valueToFind = theTree.find(value);
//                    if (valueToFind != null) {
//                        proformanceTest(theTree, value);
//                    } else {
//                        System.out.print("Could not find ");
//                        System.out.print(value + '\n');
//                    }
//                    break;
//                case 'e':
//                    return;
//                default:
//                    System.out.print("Invalid entry\n");
//            }  // end switch
//        }  // end while
//    }  // end main()
//
//    public static void proformanceTest(Tree theTree, int key) {
//        double startTime, endTime;
//        int result;
//
//        startTime = System.nanoTime();
//        theTree.find(key);
//        endTime = System.nanoTime();
//        result = (int) (endTime - startTime);
//        System.out.print("the time it took the itirative find method is: ");
//        System.out.println(result + "ns");
//
//        //recursin version:
//        startTime = System.nanoTime();
//        theTree.findRec(key);
//        endTime = System.nanoTime();
//        result = (int) (endTime - startTime);
//        System.out.print("the time it took the recursion find method is: ");
//        System.out.println(result + "ns");
//
    }
// -------------------------------------------------------------
}  // end class TreeApp
