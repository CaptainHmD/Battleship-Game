package Lab6;

////////////////////////////////////////////////////////////////
import java.util.*;

class TreeAppString {

    public static void main(String[] args) {
        String value;
        TreeString theTree = new TreeString();
        System.out.println("Weclome to Tree Test applications");
        theTree.insert("D");
        theTree.insert("B");
        theTree.insert("F");
        theTree.insert("A");
        theTree.insert("C");
        theTree.insert("E");
        theTree.insert("G");
        
        while (true) {
            System.out.println("Enter first letter of insert, find, delete,  traverse, max and min, Recursion performance, exit:");

            Scanner in = new Scanner(System.in);

            char choice = in.next().charAt(0);
            switch (choice) {
                case 'i':
                    System.out.print("Enter value to insert: ");
                    value = in.nextLine();
                    theTree.insert(value);
                    break;
                case 'f':
                    System.out.print("Enter value to find: ");
                    value = in.nextLine();
                    TNodeString found = theTree.find(value);
                    if (found != null) {
                        System.out.print("Found: ");
                        System.out.println(found);
                        System.out.print("\n");
                    } else {
                        System.out.print("Could not find ");
                        System.out.print(value + '\n');
                    }
                    break;
                case 'd':
                    System.out.print("Enter value to delete: ");
                    value = in.nextLine();
                    boolean didDelete = theTree.delete(value);
                    if (didDelete) {
                        System.out.print("Deleted " + value + '\n');
                    } else {
                        System.out.print("Could not delete ");
                        System.out.println(value);
                    }
                    break;
                case 't':
                    System.out.print("Enter type 1, 2 , 3 or 4: ");
                    int select = in.nextInt();
                    theTree.traverse(select);
                    break;
                case 'm':
                    System.out.print("Enter:\n"
                            + "1 for maximum iterative\n"
                            + "2 for minimum iterative\n"
                            + "3 for maximum recursive\n"
                            + "4 for minimum recursive");
                    select = in.nextInt();
                    theTree.maxMin(select);
                    break;
                case 'r':
                    System.out.print("Enter value to find: ");
                    value = in.nextLine();
                    TNodeString valueToFind = theTree.find(value);
                    if (valueToFind != null) {
                        proformanceTest(theTree, value);
                    } else {
                        System.out.print("Could not find ");
                        System.out.print(value + '\n');
                    }
                    break;
                case 'e':
                    return;
                default:
                    System.out.print("Invalid entry\n");
            }  // end switch
        }  // end while
    }  // end main()

    public static void proformanceTest(TreeString theTree, String key) {
        double startTime, endTime;
        int result;

        startTime = System.nanoTime();
        theTree.find(key);
        endTime = System.nanoTime();
        result = (int) (endTime - startTime);
        System.out.print("the time it took the itirative find method is: ");
        System.out.println(result + "ns");

        //recursin version:
        startTime = System.nanoTime();
        theTree.findRec(key);
        endTime = System.nanoTime();
        result = (int) (endTime - startTime);
        System.out.print("the time it took the recursion find method is: ");
        System.out.println(result + "ns");

    }
// -------------------------------------------------------------
}  // end class TreeApp
