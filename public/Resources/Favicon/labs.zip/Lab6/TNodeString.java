package Lab6;
////////////////////////////////////////////////////////////////
class TNodeString {

    private String data;              // data item (key)
    private TNodeString left;         // this node's left child
    private TNodeString right;        // this node's right child

    public TNodeString() {
        data = "";
        left = null;
        right = null;
    }
    public TNodeString(String d) {
        data = d;
        left = null;
        right = null;
    }

    public TNodeString(String d, TNodeString l, TNodeString r) {
        data = "";
        left = l;
        right = r;
    }
    
    public boolean compare(TNodeString node){
        int result = data.compareTo(node.getData());
        if (result < 0) {
            return false;
        }
        return true;
    }

    public String toString() {// display ourself
        String s= "{" + data + "} ";
        return s;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public TNodeString getLeft() {
        return left;
    }

    public void setLeft(TNodeString left) {
        this.left = left;
    }

    public TNodeString getRight() {
        return right;
    }

    public void setRight(TNodeString right) {
        this.right = right;
    }
    
}  // end class Node