package Lab6;
////////////////////////////////////////////////////////////////
class TNode {

    private int data;              // data item (key)
    private TNode left;         // this node's left child
    private TNode right;        // this node's right child

    public TNode() {
        data = 0;
        left = null;
        right = null;
    }
    public TNode(int d) {
        data = d;
        left = null;
        right = null;
    }

    public TNode(int d, TNode l, TNode r) {
        data = d;
        left = l;
        right = r;
    }

    public String toString() {// display ourself
        String s= "{" + data + "} ";
        return s;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public TNode getLeft() {
        return left;
    }

    public void setLeft(TNode left) {
        this.left = left;
    }

    public TNode getRight() {
        return right;
    }

    public void setRight(TNode right) {
        this.right = right;
    }
    
}  // end class Node
