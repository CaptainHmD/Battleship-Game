package Lab6;

import Lab4.QueueArray;
import java.util.PriorityQueue;
import java.util.Queue;

class Tree {

    public TNode root;             // first node of tree

// -------------------------------------------------------------
    public Tree() // constructor
    {
        root = null;
    }            // no nodes in tree yet
// -------------------------------------------------------------

    public void insert(int id) {
        TNode newNode = new TNode(id);    // make new node
        if (root == null) // no node in root
        {
            root = newNode;
        } else // root occupied
        {
            TNode current = root;       // start at root
            TNode parent;
            while (true) // (exits internally)
            {
                parent = current;
                if (id < current.getData()) // go left?
                {
                    current = current.getLeft();
                    if (current == null) // if end of the line,
                    {                 // insert on left
                        parent.setLeft(newNode);
                        return;
                    }
                } // end if go left
                else // or go right?
                {
                    current = current.getRight();
                    if (current == null) // if end of the line
                    {                 // insert on right
                        parent.setRight(newNode);
                        return;
                    }
                }  // end else go right
            }  // end while
        }  // end else not root
    }  // end insert()
// -------------------------------------------------------------

    public boolean delete(int key) // delete node with given key
    {                           // (assumes non-empty list)
        TNode current = root;
        TNode parent = root;
        boolean isLeftChild = true;

        while (current.getData() != key) // search for node
        {
            parent = current;
            if (key < current.getData()) // go left?
            {
                isLeftChild = true;
                current = current.getLeft();
            } else // or go right?
            {
                isLeftChild = false;
                current = current.getRight();
            }
            if (current == null) // end of the line,
            {
                return false;                // didn't find it
            }
        }  // end while
        // found node to delete

        // if no children, simply delete it
        if (current.getLeft() == null
                && current.getRight() == null) {
            if (current == root) // if root,
            {
                root = null;                 // tree is empty
            } else if (isLeftChild) {
                parent.setLeft(null);     // disconnect
            } else // from parent
            {
                parent.setRight(null);
            }
        } // if no right child, replace with left subtree
        else if (current.getRight() == null) {
            if (current == root) {
                root = current.getLeft();
            } else if (isLeftChild) {
                parent.setLeft(current.getLeft());
            } else {
                parent.setLeft(current.getLeft());
            }
        } // if no left child, replace with right subtree
        else if (current.getLeft() == null) {
            if (current == root) {
                root = current.getLeft();
            } else if (isLeftChild) {
                parent.setLeft(current.getLeft());
            } else {
                parent.setLeft(current.getLeft());
            }
        } else // two children, so replace with inorder successor
        {
            // get successor of node to delete (current)
            TNode successor = getSuccessor(current);

            // connect parent of current to successor instead
            if (current == root) {
                root = successor;
            } else if (isLeftChild) {
                parent.setLeft(successor);
            } else {
                parent.setLeft(successor);
            }

            // connect successor to current's left child
            successor.setLeft(current.getLeft());
        }  // end else two children
        // (successor cannot have a left child)
        return true;                                // success
    }  // end delete()

// -------------------------------------------------------------
    // returns node with next-highest value after delNode
    // goes to right child, then right child's left descendents
    private TNode getSuccessor(TNode delNode) {
        TNode successorParent = delNode;
        TNode successor = delNode;
        TNode current = delNode.getLeft();   // go to right child
        while (current != null) // until no more
        {                                 // left children,
            successorParent = successor;
            successor = current;
            current = current.getLeft();      // go to left child
        }
        // if successor not
        if (successor != delNode.getLeft()) // right child,
        {                                 // make connections
            successorParent.setLeft(successor.getLeft());
            successor.setLeft(delNode.getLeft());
        }
        return successor;
    }
// -------------------------------------------------------------

    public TNode find(int key) // find node with given key
    {                           // (assumes non-empty tree)
        TNode current = root;               // start at root
        while (current != null) // while no match,
        {
            if (current.getData() == key) // if no child,
            {
                return current;                 // didn't find it
            }
            if (key < current.getData()) // go left?
            {
                current = current.getLeft();
            } else // or go right?
            {
                current = current.getRight();
            }
        }
        return null;                    // found it
    }  // end find()

    private TNode findRec(int key, TNode current) // find node with given key
    {                           // (assumes non-empty tree)
        if (current == null) {
            return null;
        } else if (current.getData() == key) {
            return current;
        } else if (key < current.getData()) {
            return findRec(key, current.getLeft());
        } else {
            return findRec(key, current.getRight());
        }
    }  // end privete findRec()

    public TNode findRec(int key) // find node with given key
    {
        return findRec(key, root);
    }  // end privete findRec()

// -------------------------------------------------------------
    public void traverse(int traverseType) {
        switch (traverseType) {
            case 1:
                System.out.print("\nPreorder traversal: ");
                preOrder(root);
                break;
            case 2:
                System.out.print("\nInorder traversal:  ");
                inOrder(root);
                break;
            case 3:
                System.out.print("\nPostorder traversal: ");
                postOrder(root);
                break;
            case 4:
                System.out.print("\nLevelorder traversal: ");
                levelOrder();
                break;
                
        }
        System.out.println();
    }
// -------------------------------------------------------------

    public void preOrder() {
        preOrder(root);
    }

    private void preOrder(TNode n) {
        if (n != null) {
            System.out.print(n + " ");
            preOrder(n.getLeft());
            preOrder(n.getRight());
        }
    }
// -------------------------------------------------------------

    private void inOrder(TNode n) {
        if (n != null) {
            inOrder(n.getLeft());
            System.out.print(n + " ");
            inOrder(n.getRight());
        }
    }
// -------------------------------------------------------------

    private void postOrder(TNode n) {
        if (n != null) {
            postOrder(n.getLeft());
            postOrder(n.getRight());
            System.out.print(n + " ");
        }
    }

// -------------------------------------------------------------
    //TODO:
    //make each level in a new line
    private void levelOrder() {
    }

    public int height(TNode root) {
        if (root == null) {
            return 0;
        } else {
            int lheight = height(root.getLeft());
            int rheight = height(root.getRight());
            if (lheight > rheight) {
                return (lheight + 1);
            }else{
                return (rheight + 1);
            }
        }
    }
    
    public int nodes(TNode n){
        int left = 0;
        int right = 0;
        if (n == null) return 0;
        else {
            left = nodes(n.getLeft());
            right = nodes(n.getRight());
        }
        return left + right +1 ;
    }

    int count = 0; // number of nodes in the tree

    void preOrderV2(TNode n) {
        if (n != null) {
            count++;
            preOrderV2(n.getLeft());
            preOrderV2(n.getRight());
        }
    }

    int maxDepth(TNode n) {
        if (n == null)
            return -1;
        else {
            int lDepth = maxDepth(n.getLeft());
            int rDepth = maxDepth(n.getRight());

            /* use the larger one */
            if (lDepth > rDepth)
                return (lDepth + 1);
            else
                return (rDepth + 1);
        }
    }
    boolean ChickComplete(){
        preOrderV2(root);
        int hight=maxDepth(root)+1;
        hight = (int)(Math.pow(2,hight))-1;
        return hight == count;
    }

// -------------------------------------------------------------
    public void maxMin(int traverseType) {
        switch (traverseType) {
            case 1:
                System.out.println("maximum value: " + findMax());
                break;
            case 2:
                System.out.println("minimum value: " + findMin());
                break;
            case 3:
                System.out.println("maximum value: " + findMaxRec(root));
                break;
            case 4:
                System.out.println("minimum value: " + findMinRec(root));
                break;
            default:
                System.out.print("you enterd a wrong choice");
        }
        System.out.println();
    }

    public TNode findMax() {
        TNode p = root;
        while (p.getRight() != null) {
            p = p.getRight();
        }
        return p;
    }

    public TNode findMin() {
        TNode p = root;
        while (p.getLeft() != null) {
            p = p.getLeft();
        }
        return p;
    }

    private int findMaxRec(TNode n) {
        if (n.getRight() == null) {
            return n.getData();
        } else {
            return findMaxRec(n.getRight());
        }
    }

    private int findMinRec(TNode n) {
        if (n.getLeft() == null) {
            return n.getData();
        } else {
            return findMinRec(n.getLeft());
        }
    }
}  // end class Tree
