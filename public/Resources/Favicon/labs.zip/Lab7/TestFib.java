package Lab7;

import java.util.Scanner;

public class TestFib {

    public static void main(String[] args) {
        int n;
        long fib;

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter an integer: ");
        n = scan.nextInt();

        fib = Fib.fibBetter(n);
        System.out.println("Fib(" + n + ") is " + fib);
        
        fib = Fib.fib2(n);
        System.out.println("Fib(" + n + ") is " + fib);
    }
}
