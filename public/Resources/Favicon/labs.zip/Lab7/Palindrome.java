package Lab7;

import java.util.Scanner;

/**
 *
 * @author aahba
 */
public class Palindrome {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String word;
//        do {
//            System.out.print("Enter word to test if it's Palindrome: ");
//            word = input.next();
//
//            if (isPalindrome(word)) {
//                System.out.println("the word " + word + " is Palindrome");
//            } else {
//                System.out.println("the word " + word + " is not Palindrome");
//            }
//        } while (!input.equals(""));
//        System.out.println("\nyou entered an empty stringa and exited the program.");
        System.out.println(sum(new int[] {1,2,3,4}, 0));
    }

    public static boolean isPalindrome(String word) {
        int length = word.length();
        
        
        if (length < 2) {
            return true;
        }
        
        else if (word.charAt(0) == word.charAt(length - 1)) {
            return isPalindrome(word.substring(1, length - 1));
        }
        return false;
    }
    
    public static int sum(int[] a, int index){
        if(index == a.length -1){
            return a[index];
            
            
        } else{
            return a[index] + sum(a, index + 1);
        }
    }
}
