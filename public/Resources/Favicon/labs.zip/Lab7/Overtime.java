package Lab7;

import java.util.Scanner;

public class Overtime {

    public static void main(String[] args) {
        String fileName;	// Name of the file containing employee data
        Scanner scan = new Scanner(System.in);

        System.out.println("\nPayroll Program");
        System.out.print("Enter the name of the file containing payroll data: ");
        fileName = scan.nextLine();
        Payroll payroll = new Payroll();
        //we have two files with the names payroll and payroll2
        payroll.readPayrollInfo(fileName);
        System.out.print("The number of employees who worked more than 40 hours is: ");
        System.out.println(payroll.numOvertime());

// Instantiate a Payroll object and read in the data from the file
// Print the number of workers who worked overtime.
    }
}
