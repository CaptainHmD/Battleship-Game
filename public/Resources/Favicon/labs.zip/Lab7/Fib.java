package Lab7;

public class Fib {
//------------------------------------------------------------------

    public static long fib1(int n) {
        if (n <= 1) {
            return n;
        } else {
            return fib1(n - 1) + fib1(n - 2);
        }
    }

    
    public static long fib2(int n){
        long f1 =0;
        long f2 =1 ;
        long fib = f1+f2;
        
        for(int i=3;i <=n; i ++){
            f1=f2;
            f2=fib;
            fib = f1+f2;
        }
        return fib;
    }
    public static long fibBetter(int n) {
        return fibStart(0,1,2,n);
    }

    private static long fibStart(long f1,long f2,int count,int targetFib) {
        if (count == targetFib) {
            return f1 + f2;
        } else {
            return fibStart(f2, f1 + f2,++count, targetFib);
        }
    }
}
