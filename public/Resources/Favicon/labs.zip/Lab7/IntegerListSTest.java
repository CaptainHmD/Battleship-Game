package Lab7;

import java.util.Scanner;

public class IntegerListSTest {

    static IntegerListS list = new IntegerListS(10);
    static Scanner scan = new Scanner(System.in);

//
//	Creates a list, then repeatedly print the menu and do what the
//	user asks until they quit.
//
    public static void main(String[] args) {
        printMenu();
        int choice = scan.nextInt();
        while (choice != 0) {
            dispatch(choice);
            printMenu();
            choice = scan.nextInt();
        }
    }

//
// Does what the menu item calls for.
//
    public static void dispatch(int choice) {
        int loc;
        switch (choice) {
            case 0:
                System.out.println("Bye!");
                break;
            case 1:
                System.out.println("How big should the list be?");
                int size = scan.nextInt();
                list = new IntegerListS(size);
                list.randomize();
                break;
            case 2:
                list.selectionSort();
                break;
            case 3:
                System.out.print("Enter the value to look for: ");
                loc = list.linearSearch(scan.nextInt());
                if (loc != -1) {
                    System.out.println("Found at location " + loc);
                } else {
                    System.out.println("Not in list");
                }
                break;
            case 4:
                System.out.print("Enter the value to look for: ");
                loc = list.linearSearchRec(scan.nextInt());
                if (loc != -1) {
                    System.out.println("Found at location " + loc);
                } else {
                    System.out.println("Not in list");
                }
                break;
                case 5:
                System.out.print("Enter the value to look for: ");
                loc = list.binarySearchR(scan.nextInt());
                if (loc != -1) {
                    System.out.println("Found at location " + loc);
                } else {
                    System.out.println("Not in list");
                }
                break;
            case 6:
                list.print();
                break;
            default:
                System.out.println("Sorry, invalid choice");
        }
    }

//
//	Prints the menu of user's choices.
//
    public static void printMenu() {
        System.out.println("\n		Menu	");
        System.out.println("	====");
        System.out.println("0: Quit");
        System.out.println("1: Create new list elements (** do this first!! **)");
        System.out.println("2: Sort the list using selection sort");
        System.out.println("3: Find an element in the list using linear search");
        System.out.println("4: Find an element in the list using recursive linear search");
        System.out.println("5: Find an element in the list using recursive binary search");
        System.out.println("6: Print the list");
        System.out.print("\nEnter your choice: ");
    }
}
