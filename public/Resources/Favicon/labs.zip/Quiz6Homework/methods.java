package Quiz6Homework;

/**
 *
 * @author aahba
 */
public class methods {

    public static int minGap(int[] arr) {
        int minGap = Math.abs(arr[0] - arr[1]);
        System.out.println("cuurent Gap is: " + minGap);

        for (int i = 1; i < arr.length - 1; i++) {
            int currentGap = Math.abs(arr[i] - arr[i + 1]);
            System.out.println("cuurent Gap is: " + currentGap);
            if (currentGap < minGap) {
                minGap = currentGap;
            }
        }

        return minGap;
    }

    public static double evenPercentage(int[] arr) {
        int counter = 0;

        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] % 2 == 0) {
                counter++;
            }
        }
        double result = ((double)counter / arr.length) * 100;
        return result;
    }

    public static int[] appendArrays(int[] arr1, int[] arr2) {
        int[] result = new int[arr1.length + arr2.length];
        int counter = 0;
        //appending the first array
        for (int i = 0; i < arr1.length; i++) {
            result[counter] = arr1[i];
            counter++;
        }
        //appending the second array
        for (int i = 0; i < arr2.length; i++) {
            result[counter] = arr2[i];
            counter++;
        }

        return result;
    }

    public static void swapAll(int[] arr1, int[] arr2) {
        int temp;
        for (int i = 0; i < arr1.length; i++) {
            temp = arr1[i];
            arr1[i] = arr2[i];
            arr2[i] = temp;
        }
    }

    public static int longestSortedSequence(int[] arr) {
        int longestLength = 1;
        int firstIndex = 0;
        int currentLength = 1;
        int currentFirstIndex = 0;

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] >= arr[i - 1]) {
                currentLength++;
                if(currentLength > longestLength){
                    firstIndex = currentFirstIndex;
                    longestLength = currentLength;
                }

            } else {
                currentLength = 1;
                currentFirstIndex = i;
            }

        }
        System.out.print("the longest oredred sequnec is: [");
        for (int i = firstIndex; i < firstIndex + longestLength; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("]");
        
        return longestLength;
    }

    public static void main(String[] args) {
        //create an array to use for testing purposes
        int[] arr1 = {1, 3, 6, 7, 12};
        int[] arr2 = {2, 4, 3, 9, 5};

        //finding the minimum gap between elemnt in an array
        System.out.println("the minimum gap in the array1 is: " + minGap(arr1) + "\n");

        //finding the percentage of even numbers in an array
        System.out.println("the even numbers percentage in the array1 is: " + evenPercentage(arr1) + "%\n");

        //appenditn two arrays
        System.out.println("appending the two arrays");
        int[] appendedArray = appendArrays(arr1, arr2);
        System.out.print("[");
        for (int i = 0; i < appendedArray.length; i++) {
            System.out.print(appendedArray[i] + " ");
        }
        System.out.println("]\n");

        //swapping the two arrays
        System.out.println("before swapping the two arrays");
        System.out.print("array 1: ");
        System.out.print("[");
        for (int i = 0; i < arr1.length; i++) {
            System.out.print(arr1[i] + " ");
        }
        System.out.println("]");
        System.out.print("array 2: ");
        System.out.print("[");
        for (int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i] + " ");
        }
        System.out.println("]");

        swapAll(arr1, arr2);
        System.out.println("after swapping:");
        System.out.print("array 1: ");
        System.out.print("[");
        for (int i = 0; i < arr1.length; i++) {
            System.out.print(arr1[i] + " ");
        }
        System.out.println("]");
        System.out.print("array 2: ");
        System.out.print("[");
        for (int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i] + " ");
        }
        System.out.println("]\n");
        
        //prining the longest oredered sequence in the array
        System.out.println("prining the longest oredered sequence in the array1");
        System.out.println("and the length of it is: " + longestSortedSequence(arr1));
        
    }
}
