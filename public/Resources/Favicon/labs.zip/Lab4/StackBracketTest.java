package Lab4;

import java.io.IOException;
import java.util.Scanner;

/**
 * Implement a Symbol Balancer. Which tests and expression containing brackets
 * [](){} and determines if brackets are balanced. Implementation uses a
 * StackArray.
 *
 * @version 1.0 08
 * @author
 */
public class StackBracketTest {

    private String input;

    /**
     * Default Constructor
     *
     */
    public StackBracketTest() {
        input = null;
    }

    /**
     * Alternate Constructor Sets Expression to be evaluated
     *
     * @param in string containing expression to be balanced
     */
    public StackBracketTest(String in) {
        // complete this constructor
        input = in;
    }

    /**
     * Set string containing expression to be evaluated
     *
     * @param in string containing expression to be balanced
     */
    public void setExpression(String in) {
        input = in;
    }

    /**
     * Evaluate expression and determine correctness
     *
     */
    public boolean check() {
        int stackSize = input.length();
        StackArray theStack = new StackArray(stackSize);
        
        for (int j = 0; j < input.length(); j++) {
            char ch = input.charAt(j);
            // complete the following switch statement. 
            switch (ch) {
                case '[':
                    theStack.push('[');
                    break;
                case '(':
                    theStack.push('(');
                    break;
                case '{':
                    theStack.push('{');
                    break;
                case ')':
                    if (theStack.isEmpty()) {
                        return false;
                    } else if('(' != theStack.pop()) {
                        return false;
                    }//stack
                    break;
                case ']':
                    if (!theStack.isEmpty()) {
                        if ('[' != theStack.pop()) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                    break;
                case '}':
                    if (!theStack.isEmpty()) {
                        if ('{' != theStack.pop()) {
                            return false;
                        }
                    } else {
                        return false;
                    }
            }
        }
        // Test that the stack is empty. If not the expression is invalid
        if (!theStack.isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * This main method implements a little interactive test program which when
     * executed repeatedly prompts the user for an expression and tests the
     * expression.
     */
    public static void main(String[] args) throws IOException {
        String s = "";
        StackBracketTest stack = new StackBracketTest(s);

        do {
            System.out.print("Enter string containing delimiters: ");
            // read a string from the console using the Scanner class. 
            Scanner scan = new Scanner(System.in);
            s = scan.nextLine();
            // can you determine what this if statement is doing?  

            // pass the string to the StackBracketTest object created
            // above using the most appropriate method.
            stack.setExpression(s);
            if (stack.check()) {
                System.out.println("this statment is valid");
            } else {
                System.out.println("this statment is not valid");
            }
            // Call the StackBracketTest check method.
            // Test result of check method and display result in form of
            // a message to the user e.g. “This statement is valid” 

        } while (!s.equals(""));
    }
}
