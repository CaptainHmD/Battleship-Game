package Lab4;

class StackArray {

    private int capacity;        // size of stack array
    private char[] a;
    private int nElems;              // top of stack
//--------------------------------------------------------------

    public StackArray(int s) {         // constructor
        capacity = s;             // set array size
        a = new char[capacity];  // create array
        nElems = 0;                // no items yet
    }
//--------------------------------------------------------------

    public void push(char j) {    // put item on top of stack
        if (nElems == a.length) {
            System.out.println("there no space in the stack");
        } else {
            a[nElems] = j;     // increment top, insert item
            nElems++;
        }
    }
//--------------------------------------------------------------

    public char pop() {         // take item from top of stack
        if (isEmpty()) {
            System.out.println("there no elemnt in the stack");
            return 0;
        }
        nElems--;
        char temp = a[nElems];
        return temp;  // access item, decrement top
    }
//--------------------------------------------------------------

    public char peek() {         // peek at top of stack
        int top = nElems - 1;
        return a[top];
    }
//--------------------------------------------------------------

    public boolean isEmpty() {    // true if stack is empty
        if (nElems == 0) {
            return true;
        } else {
            return false;
        }
    }
//--------------------------------------------------------------

    public boolean isFull() {    // true if stack is full
        return (nElems == capacity);
    }
//--------------------------------------------------------------
}
