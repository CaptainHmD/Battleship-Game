package Lab3;


public class HighArrayDynamic extends Lab2.HighArray {

    public HighArrayDynamic(int max) {
        super(max);
    }

    //this method double the size of array
    public void increaseSize() {
        long[] temp = new long[a.length * 2];
        for (int i = 0; i < nElems; i++) {
            temp[i] = a[i];
        }
        a = temp;
    }

    public void decreaseSize() {
        long[] temp = new long[a.length / 2];
        for (int i = 0; i < nElems; i++) {
            temp[i] = a[i];
        }
        a = temp;
    }

    public void addFirst(long elem) {
        if (nElems == a.length) {
            this.increaseSize();
        }

        if (nElems == 0) {
            nElems++;
            a[0] = elem;
        } else {

            for (int i = nElems; i > 0; i--) {
                a[i] = a[i - 1];
            }
            a[0] = elem;
            nElems++;
        }

    }

    public void removeFirst() {
        if (nElems < a.length / 2) {
            decreaseSize();
        }
        if (nElems != 0) {

            for (int i = 1; i < nElems; i++) {
                a[i - 1] = a[i];
            }
            nElems--;
        }
    }

    public void addAt(int index, long elem) {
        if (nElems == a.length) {
            this.increaseSize();
        }

        if (index < 0) {
            System.out.println("the index can't be negative");
        } else {
            for (int i = nElems; i > index; i--) {
                a[i] = a[i - 1];
            }
            nElems++;
            a[index] = elem;
        }
    }

    public long removeAt(int index) {
        if (nElems < a.length / 2) {
            decreaseSize();
        }

        if (index > (nElems - 1) || index < 0) {
            System.out.println("the index is out of boundary");
            return -1;
        } else {
            long removedItem = a[index];
            for (int i = index ; i < nElems -1; i++) {
                a[i] = a[i + 1];
            }

            nElems--;
            return removedItem;
        }
    }

    public long[] toArray() {
        long[] result = new long[nElems];
        for (int i = 0; i < nElems; i++) {
            result[i] = a[i];
        }
        return result;
    }

    public void set(int index, long elem) {
        if (index > (nElems - 1) || index < 0) {
            System.out.println("the index is out of boundary");
        } else {
            a[index] = elem;
        }
    }

    public long get(int index) {
        if (index > (nElems - 1) || index < 0) {
            System.out.println("the index is out of boundary");
            return -1;
        } else {
            return a[index];
        }
    }

    public void clear() {
        nElems = 0;
    }

    public void insertionSort() {
        int i, j, k;
        long temp;
        for (i = 1; i < nElems; i++) {
            temp = a[i];
            for (j = 0; j < i; j++) {
                if (temp < a[j]) {
                    break;
                }
            }
            for (k = i; k > j; k--) {
                a[k] = a[k - 1];
            }
            a[j] = temp;
        }

    }
    
    public void selcetionSort(){
        int min , i, j;
        long temp;
        for ( i = 0; i < nElems; i++) {
            min = i;
            for ( j = i + 1; j < nElems; j++) {
                if (a[j] < a[min]) {
                    min = j;
                }
            }
            temp = a[i];
            a[i] = a[min];
            a[min] = temp;
        }    
    }
    public void bubbleSort(){
        long temp;
        for (int i = 0; i < nElems-1; i++) {
            for (int j = 0; j < nElems-1; j++) {
                if (a[j] > a[j+1]) {
                    temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                }
            }
        }
    }
}
