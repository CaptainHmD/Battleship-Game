/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassActivityWeekOne;

/**
 *
 * @author s441016576
 */
public class RangeMethods {

    public static void main(String[] args) {

        int[] numbers = new int[5];

        //this for the linear growth
        System.out.println("\tN\t|\tO(n)");
        for (double i = 1; i < 6; i++) {
            numbers = new int[(int) Math.pow(10, i)];
            System.out.printf(numbers.length + "      \t|");

            for (int j = 0; j < numbers.length; j++) {//randomzing the array
                numbers[j] = (int) (Math.random() * 100) + 1;
            }

            System.out.printf("\t%.0f mili seconds\n", linear(numbers));
        }
        //this for the quadratic growth
        System.out.println("\n\n\tN\t|\tO(n^2)");
        for (double i = 1; i < 6; i++) {
            numbers = new int[(int) Math.pow(10, i)];
            System.out.printf(numbers.length + "      \t|");

            for (int j = 0; j < numbers.length; j++) {//randomzing the array
                numbers[j] = (int) (Math.random() * 100) + 1;
            }

            System.out.printf("\t%.0f mili seconds\n", quadratic(numbers));
        }
        //this for the cubic growth
        System.out.println("\n\n\tN\t|\tO(n^3)");
        for (double i = 1; i < 3; i++) {
            numbers = new int[(int) Math.pow(10, i)];
            System.out.printf(numbers.length + "      \t|");

            for (int j = 0; j < numbers.length; j++) {//randomzing the array
                numbers[j] = (int) (Math.random() * 100) + 1;
            }

            System.out.printf("\t%.0f mili seconds\n", cubic(numbers));
        }
    }

    public static double cubic(int[] numbers) {
        int maxDiff = 0;     // look at each pair of values
        int diff = 0;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 0; i < numbers.length; i++) {
            for (int j = 0; j < numbers.length; j++) {
                for (int k = 0; k < numbers.length; k++) {
                    loopCount++;
                    diff = Math.abs(numbers[j] - numbers[i]);
                    if (diff > maxDiff) {
                        maxDiff = diff;
                    }
                }
            }
        }
        double endtime = System.nanoTime();;
//        System.out.println(((endtime - starttime)) + " nano seconds");
//        System.out.println("the loop count for method range1 is: " + loopCount);
        double total = (endtime - starttime);
        return total / 1000f;
    }

    public static double quadratic(int[] numbers) {
        int maxDiff = 0;     // look at each pair of values
        int diff = 0;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                loopCount++;
                diff = Math.abs(numbers[j] - numbers[i]);
                if (diff > maxDiff) {
                    maxDiff = diff;
                }
            }
        }
        double endtime = System.nanoTime();
//        System.out.println(((endtime - starttime)) + " nano seconds");
//        System.out.println("the loop count for method quadratic is: " + loopCount);
        double total = (endtime - starttime);
        return total / 1000f;
    }

    public static double linear(int[] numbers) {
        int max = numbers[0];     // find max/min values
        int min = max;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 1; i < numbers.length; i++) {
            loopCount++;
            if (numbers[i] < min) {
                min = numbers[i];
            }
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        double endtime = System.nanoTime();;
//        System.out.println(((endtime - starttime)) + " nano seconds");
//        System.out.println("the loop count for method linear is: " + loopCount);
        double total = (endtime - starttime);
        return total / 1000f;
    }

}
