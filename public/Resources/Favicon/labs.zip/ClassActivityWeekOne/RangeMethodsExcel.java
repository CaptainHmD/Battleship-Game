package ClassActivityWeekOne;

import com.gembox.spreadsheet.*;
import com.gembox.spreadsheet.charts.ChartType;
import com.gembox.spreadsheet.charts.ExcelChart;
import java.awt.Desktop;
import java.io.File;

class RangeMethodsExcel {

    public static void main(String[] args) throws java.io.IOException {
        // If using Professional version, put your serial key below.
        SpreadsheetInfo.setLicense("FREE-LIMITED-KEY");

        ExcelFile workbook = new ExcelFile();
        ExcelWorksheet worksheet = workbook.addWorksheet("RangeMethodsExcel");

        //setteng the style for the headres
        worksheet.getCell(0, 0).setValue("complexity in milli seconds");
        worksheet.getColumn(0).setWidth(100, LengthUnit.POINT);
        worksheet.getCell(0, 0).getStyle().getFont().setSize(18 * 10);
        worksheet.getCell(0, 0).getStyle().getFillPattern().setSolid(SpreadsheetColor.fromArgb(211, 211, 211));
        worksheet.getCell(0, 0).getStyle().getBorders().setBorders(MultipleBorders.outside(), SpreadsheetColor.fromName(ColorName.BLACK), LineStyle.THIN);

        worksheet.getCells().getStyle().setHorizontalAlignment(HorizontalAlignmentStyle.CENTER);
        worksheet.getCells().getSubrange("A2:A4").getStyle().getFillPattern().setSolid(SpreadsheetColor.fromArgb(211, 211, 211));
        worksheet.getCells().getSubrange("B1:F1").getStyle().getFillPattern().setSolid(SpreadsheetColor.fromArgb(211, 211, 211));

        //set the the N values for each row
        for (int i = 1; i < 6; i++) {
            worksheet.getCell(0, i).setValue(Math.pow(10, i));
            worksheet.getCell(0, i).getStyle().setNumberFormat("\"\"#,##0");
            worksheet.getCell(0, i).getStyle().getBorders().setBorders(MultipleBorders.outside(), SpreadsheetColor.fromName(ColorName.BLACK), LineStyle.THIN);

        }
        //set the header row for each collumn
        for (int i = 1; i < 4; i++) {
            if (i < 3) {
                worksheet.getCell(i, 0).setValue("O(N" + i + ")");
                worksheet.getCell(i, 0).getStyle().getBorders().setBorders(MultipleBorders.outside(), SpreadsheetColor.fromName(ColorName.BLACK), LineStyle.THIN);
                worksheet.getCell(i, 0).getCharacters(3, 1).getFont().setScriptPosition(ScriptPosition.SUPERSCRIPT);
            } else {
                worksheet.getCell(i, 0).setValue("O(log2n)");
                worksheet.getCell(i, 0).getStyle().getBorders().setBorders(MultipleBorders.outside(), SpreadsheetColor.fromName(ColorName.BLACK), LineStyle.THIN);
                worksheet.getCell(i, 0).getCharacters(5, 1).getFont().setScriptPosition(ScriptPosition.SUBSCRIPT);
            }

        }

        //filling the table with seconds for each complexity
        for (int i = 1; i < 6; i++) {
            int n = worksheet.getCell(0, i).getIntValue();
            int[] arr = new int[n];

            for (int j = 0; j < arr.length; j++) {//randomzing the array
                arr[j] = (int) (Math.random() * 100) + 1;
            }

            worksheet.getCell(1, i).setValue(linear(arr));
            worksheet.getCell(2, i).setValue(quadratic(arr));
            worksheet.getCell(3, i).setValue(logarithmic(arr));
        }
//        ExcelChart chart = worksheet.getCharts().add(ChartType.LINE, "H2", "M20");
//        chart.selectData(worksheet.getCells().getSubrange("A1:F4"), false, false);
//        chart.getSeries().add(worksheet.getCell(1,0).getValue().toString(), "B1:F1");
//        chart.getSeries().add(worksheet.getCell(2,0).getValue().toString(), "B2:F2");
//        chart.getSeries().add(worksheet.getCell(3,0).getValue().toString(), "B2:F2");

        //here after saving the data we open it using java api
        workbook.save("RangeMethodsExcel.xlsx");
        File file = new File("RangeMethodsExcel.xlsx");
        Desktop.getDesktop().open(file); 
    }

    ////////////////////////////////////////////////////////
    //here we define each complexity
    public static double linear(int[] numbers) {
        int max = numbers[0];     // find max/min values
        int min = max;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 1; i < numbers.length; i++) {
            loopCount++;
            if (numbers[i] < min) {
                min = numbers[i];
            }
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        double endtime = System.nanoTime();
        double total = (endtime - starttime);
        return total / 1000f;
    }

    public static double quadratic(int[] numbers) {
        int maxDiff = 0;     // look at each pair of values
        int diff = 0;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                loopCount++;
                diff = Math.abs(numbers[j] - numbers[i]);
                if (diff > maxDiff) {
                    maxDiff = diff;
                }
            }
        }
        double endtime = System.nanoTime();
        double total = (endtime - starttime);
        return total / 1000f;
    }

    public static double logarithmic(int[] numbers) {
        int max = numbers[0];     // find max/min values
        int min = max;
        int loopCount = 0;
        double starttime = System.nanoTime();
        for (int i = 1; i < numbers.length; i = i * 2) {
            loopCount++;
            if (numbers[i] < min) {
                min = numbers[i];
            }
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        double endtime = System.nanoTime();
        double total = (endtime - starttime);
        return total / 1000f;
    }
}
