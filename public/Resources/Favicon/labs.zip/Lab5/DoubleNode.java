package Lab5;

/**
 *
 * @author aahba
 */
public class DoubleNode {

    private DoubleNode next;
    private DoubleNode previous;
    private int data;

    public DoubleNode() {
        this.next = null;
        this.previous = null;
        this.data = 0;
    }

    public DoubleNode(int value) {
        this.next = null;
        this.previous = null;
        this.data = value;
    }

    public DoubleNode(int data, DoubleNode next) {
        this.next = next;
        this.previous = null;
        this.data = data;
    }

    public DoubleNode(int data, DoubleNode next, DoubleNode previous) {
        this.next = next;
        this.previous = null;
        this.data = data;
    }

    public DoubleNode getNext() {
        return next;
    }

    public void setNext(DoubleNode next) {
        this.next = next;
    }

    public DoubleNode getPrevious() {
        return previous;
    }

    public void setPrevious(DoubleNode previous) {
        this.previous = previous;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "DoubleNode{" + "data=" + data + '}';
    }
    
    
}
