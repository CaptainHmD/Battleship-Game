package Lab5;

class LinkListApp {

    public static void main(String[] args) {
        LinkList theList = new LinkList();  // make list

        theList.insertFirst(new Node(1));      // insert 4 items
        theList.insertFirst(new Node(1));
        theList.insertFirst(new Node(3));
        theList.insertFirst(new Node(4));
        theList.insertFirst(new Node(5));
        
        System.out.println(theList.searchR(theList.getFirst(),4));
//
//        theList.displayList();              // display list
//
//        Node n = theList.find(5);          // find item
//        if (n != null) {
//            System.out.println("Found link with key " + n.getData());
//        } else {
//            System.out.println("Can't find link");
//        }
//
//        Node d = theList.delete(5);       // delete item
//        if (d != null) {
//            System.out.println("Deleted link with key " + d.getData());
//        } else {
//            System.out.println("Can't delete link");
//        }
//
//        theList.displayList();              // display list
//        theList.deleteLast();
//        theList.displayList();
//        theList.deleteFirst();
//        theList.displayList();
//        theList.insertLast(new Node(2));
//        theList.displayList();
//        theList.insertLast(new Node(3));
//        theList.displayList();
//
//        System.out.println("*************************");
//        System.out.println("info about the array");
//        System.out.println("the sum of the array elements: " + theList.sum());
//        System.out.println("the average of the array elements:" + theList.avg());
//        System.out.println("is the array elemenst ordered: " + theList.isOrdered());
//        System.out.println("is the array elemenst unique: " + theList.isUnique());
//        System.out.println("the maximum number in the array: " + theList.max());
//        System.out.println("the minimum number in the array: " + theList.min());
//        System.out.println("the range for the array elemnts: " + theList.range());
//        System.out.println("the array before removing the dublicates: ");
//        theList.insertLast(new Node(2));
//        theList.insertLast(new Node(3));
//        theList.insertLast(new Node(4));
//        theList.displayList();
//
//        System.out.println("the array after removing the dublicates: ");
//        theList.removeDublicates();
//        theList.displayList();
//
//        System.out.println("*******************************");
//        System.out.println("now we will do linked list operations");
//        LinkList secondList = new LinkList();
//        secondList.insertLast(new Node(3));
//        secondList.insertLast(new Node(4));
//        secondList.insertLast(new Node(5));
//        secondList.insertLast(new Node(6));
//        System.out.print("the first list is: ");
//        theList.displayList();
//        System.out.print("the second list is: ");
//        secondList.displayList();
//
//        System.out.print("the union of the two list: ");
//        ListOps.union(theList, secondList).displayList();
//
//        System.out.print("the difference between the first list and the second list is: ");
//        ListOps.difference(theList, secondList).displayList();
//        
//        System.out.print("the intersection of the two list: ");
//        ListOps.intersection(theList, secondList).displayList();
//        System.out.println(secondList.check(secondList.getFirst(), 10));

    }  // end main()
}  // end class LinkList2App
