package Lab5;

/**
 *
 * @author aahba
 */
public class StackAndQueueApp {
        
    public static void main(String[] args) {
        StackLinkList stack = new StackLinkList();
        System.out.println("the stack operations:");
        stack.push(1);
        stack.dispay();
        stack.push(2);
        stack.dispay();
        stack.push(3);
        stack.dispay();
        stack.push(4);
        stack.dispay();
        System.out.print("the stack has: ");
        stack.dispay();
        Node node = stack.pop();
        System.out.println("the elemnent in top of stack is: " + node);
        System.out.print("the stack after the pop : ");
        stack.dispay();
        System.out.println("*************************************");
        
        System.out.println("the queue operation:");
        QueueLinkList queue = new QueueLinkList();
        queue.enQueue(1);
        queue.dispay();
        queue.enQueue(2);
        queue.dispay();
        queue.enQueue(3);
        queue.dispay();
        queue.enQueue(4);
        queue.dispay();
        System.out.print("the stack now has: ");
        queue.dispay();
        node = queue.deQueue();
        System.out.println("the elemnent in top of stack is: " + node);
        System.out.print("the stack after the pop : ");
        queue.dispay();
    }
}
