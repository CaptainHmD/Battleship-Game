package Lab4;

import java.util.Scanner;

/**
 *
 * @author aahba
 */
public class InfixToPostfix {

    public static String infix2postfix(String infix) {
        int stackSize = infix.length();
        StackArray stack = new StackArray(stackSize);
        StringBuffer postfix = new StringBuffer();
        char ch;

        for (int i = 0; i < infix.length(); i++) {
            if (Character.isDigit(infix.charAt(i))) {
                postfix.append(infix.charAt(i));

            } else if (infix.charAt(i) == '(') {
                stack.push(infix.charAt(i));

            } else if (infix.charAt(i) == ')') {
                ch = stack.peek();
                while (ch != '(' && !stack.isEmpty()) {
                    postfix.append(ch);
                    stack.pop();
                    ch = stack.peek();
                }
                stack.pop();

            } else {
                if (!stack.isEmpty() && stack.peek() != '(') {
                    ch = stack.pop();
                    postfix.append(ch);
                }
                stack.push(infix.charAt(i));
            }
        } // end for

        while (!stack.isEmpty()) {
            ch = stack.pop();
            postfix.append(ch);
        }

        return postfix.toString();
    }

    public static int calcPost(String exp) {
        int stackSize = exp.length();
        StackInteger stack = new StackInteger(stackSize);
        StringBuffer postfix = new StringBuffer();
        char ch;
        int value;
        int result = 0;

        for (int i = 0; i < exp.length(); i++) {
            ch = exp.charAt(i);
            if (Character.isDigit(ch)) {
                stack.push(Character.getNumericValue(ch));
            } else {
                switch (ch) {
                    case '+':
                        value = stack.pop() + stack.pop();
                        stack.push(value);
                        break;
                    case '-':
                        value = stack.pop() - stack.pop();
                        stack.push(value);
                        break;
                    case '*':
                        value = stack.pop() * stack.pop();
                        stack.push(value);
                        break;
                    case '/':
                        value = stack.pop() / stack.pop();
                        stack.push(value);
                }
            }
        }
        return result = stack.pop();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("please enter an infix to convert it to postfix: ");
        String infix = input.nextLine();

        while (infix != "") {
            String postfix = infix2postfix(infix);
            System.out.println("the expression after conversion is: " + postfix);
            int result = calcPost(postfix);
            System.out.println("and the resulted value of it is: " + result);
            System.out.println("******************************************");
            System.out.print("please enter an infix to convert it to postfix: ");
            infix = input.nextLine();
        }

    }
}
