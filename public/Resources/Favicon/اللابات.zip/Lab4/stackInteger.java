package Lab4;

class StackInteger {

    private int capacity;        // size of stack array
    private int[] a;
    private int nElems;              // top of stack
//--------------------------------------------------------------

    public StackInteger(int s) {         // constructor
        capacity = s;             // set array size
        a = new int[capacity];  // create array
        nElems = 0;                // no items yet
    }
//--------------------------------------------------------------

    public void push(int j) {    // put item on top of stack
        if (nElems == a.length) {
            System.out.println("there no space in the stack");
        } else {
            a[nElems] = j;     // increment top, insert item
            nElems++;
        }
    }
//--------------------------------------------------------------

    public int pop() {         // take item from top of stack
        if (isEmpty()) {
            System.out.println("there no elemnt in the stack");
            return 0;
        }
        nElems--;
        int temp = a[nElems];
        return temp;  // access item, decrement top
    }
//--------------------------------------------------------------

    public int peek() {         // peek at top of stack
        int top = nElems - 1;
        return a[top];
    }
//--------------------------------------------------------------

    public boolean isEmpty() {    // true if stack is empty
        if (nElems == 0) {
            return true;
        } else {
            return false;
        }
    }
//--------------------------------------------------------------

    public boolean isFull() {    // true if stack is full
        return (nElems == capacity);
    }
//--------------------------------------------------------------
}
