/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab1;

import java.util.Scanner;


public class IntegerList {

    int[] list; //values in the list
    int size = 0;

//-------------------------------------------------------
//create a list of the given size
//-------------------------------------------------------
    public IntegerList(int size) {
        list = new int[size];
    }

//-------------------------------------------------------
//fill array with integers between 1 and 100, inclusive
//-------------------------------------------------------
    public void randomize() {
        for (int i = 0; i < list.length; i++) {
            list[i] = (int) (Math.random() * 100) + 1;
        }
        size = list.length;
    }
//-------------------------------------------------------
//print array elements with indices
//-------------------------------------------------------

    public void print() {
        for (int i = 0; i < list.length; i++) {
            System.out.println(i + ":\t" + list[i]);
        }
    }

    //this method double the size of array
    public void increaseSize() {
        int[] temp = new int[list.length * 2];
        for (int i = 0; i < list.length; i++) {
            temp[i] = list[i];
        }
        list = temp;
    }

    //will add elements to the list
    public void addElement(int elem) {
        if (list.length == size) {
            increaseSize();
        }
        list[size] = elem;
        size++;
    }

    //this mithod delets thefirst occurence of elemnt then shift the rest of the element in the list to the left
    public void removeFirst(int elem) {

        boolean isDeleted = false;// this will check if we deleted the item or not

        for (int i = 0; i < list.length; i++) {
            if (!isDeleted) {//if the item is not deleted it will seach for the elemdnt to delete
                if (list[i] == elem) {
                    list[i] = 0;
                    isDeleted = true;
                    size--;
                }
            } else {//here we are shifting the elements to the left
                list[i - 1] = list[i];
                list[i] = 0;
            }
        }
        if (!isDeleted) {
            System.out.println("there no weren't any " + elem + " in the list");
        }
    }

    public void removeAll(int elem) { 
        boolean Deleted = false;

        //here we will delete elem and increase the shift amount if we find the elemtn each time
        for (int i = 0; i < list.length; i++) {

            if (list[i] == elem) {
                size--;
                Deleted = true;
                i--;// will decreamnt the i because:
                // maybe there will be the same elemnt we want to delete in sequence
                
                
                //here will shift the elements to the left for every item we delete
                for (int j = i + 2; j < list.length; j++) {
                    list[j - 1] = list[j];
                    list[j] = 0;
                }
            }
        }

        if (!Deleted) {
            System.out.println("there no weren't any " + elem + " in the list");
        }
    }
}

// ***************************************************************
// IntegerListTest.java
//
// Provide a menu-driven tester for the IntegerList class.
//
// *************************************************************** import java.util.Scanner;
class IntegerListTest {

    static IntegerList list = new IntegerList(10);
    static Scanner scan = new Scanner(System.in);

//-------------------------------------------------------
// Create a list, then repeatedly print the menu and do what the
// user asks until they quit
//-------------------------------------------------------
    public static void main(String[] args) {
        printMenu();
        int choice = scan.nextInt();
        while (choice != 0) {
            dispatch(choice);
            printMenu();
            choice = scan.nextInt();
        }
    }

//-------------------------------------
// Do what the menu item calls for
//-------------------------------------
    public static void dispatch(int choice) {

        switch (choice) {
            case 0:
                System.out.println("Bye! ");
                break;
            case 1:
                System.out.println("How big should the list be?");
                int size = scan.nextInt();
                list = new IntegerList(size);
                list.randomize();
                break;
            case 2:
                list.print();
                break;
            case 3:
                System.out.println("what is the elemnet you want to add?");
                int addElem = scan.nextInt();
                list.addElement(addElem);
                break;
            case 4:
                System.out.println("what is the elemnet you want to remove?");
                int removeFirstElem = scan.nextInt();
                list.removeFirst(removeFirstElem);
                break;
            case 5:
                System.out.println("what is the elemnet you want to remove all occurrence of it?");
                int removeAllElem = scan.nextInt();
                list.removeAll(removeAllElem);
                break;
            default:
                System.out.println("Sorry, invalid choice");
        }
    }

//----------------------------
// Print the user's choices
//----------------------------
    public static void printMenu() {
        System.out.println("\n Menu	");
        System.out.println("	====");
        System.out.println("0: Quit");
        System.out.println("1: Create a new list (** do this first!! **)");
        System.out.println("2: Print the list");
        System.out.println("3: add an element to the list");
        System.out.println("4: remove an element from the list");
        System.out.println("5: remove all occurrence of an element from the list");
        System.out.print("\nEnter your choice: ");
    }
}
