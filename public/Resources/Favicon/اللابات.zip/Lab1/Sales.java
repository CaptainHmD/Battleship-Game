package Lab1;


import java.util.Scanner;
import java.util.ArrayList;

public class Sales {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("please enter the number of sales people:");
        final int SALESPEOPLE = scan.nextInt();
        int[] sales = new int[SALESPEOPLE];
        int sum;
        
        int maxIndex= 0;
        int minIndex = 0;

        
        /// input sales values
        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for salesperson " + (i + 1) + ": ");
            sales[i] = scan.nextInt();
        }
        
        
        // calculates maxIndex
        for (int i = 0; i < sales.length; i++) {
            if(sales[maxIndex] < sales[i]){
                maxIndex = i;
            }
        }
        // calcluae minIndex
        for (int i = 0; i < sales.length; i++) {
            if(sales[minIndex] < sales[i]){
                minIndex = i;
            }
        }    


        System.out.println("\nSalesperson Sales\n");

        sum = 0;
        for (int i = 0; i < sales.length; i++) {
            System.out.println("the id of the sales man: " + (i+1) + " his sales: " + sales[i]);
            sum += sales[i];
        }
        //here will be printing the final result of the report
        System.out.println("\nTotal sales: " + sum);
        System.out.println("the average sales is: " + (sum / SALESPEOPLE) + "\n");
        
        System.out.println("the perosn id with heighest sales is: " + maxIndex+1);
        System.out.println("and the amount is: " + sales[maxIndex] + "SR\n");
        
        System.out.println("for the person id with the least sales is: " + minIndex+1);
        System.out.println("and the amount is: " + sales[minIndex] + "SR\n");
        
        System.out.println("enter a target to check who reach it:");
        int target = scan.nextInt();
        int numPeopleTarget = 0;// for holding the number of sales peopla reached the target
        int[] peopleTarget = new int[SALESPEOPLE];// to hold the indexes of each sales people reached the target
        for (int i = 0; i < sales.length; i++) {
            if(sales[i] >= target){
                peopleTarget[numPeopleTarget] = i;
                numPeopleTarget++;
            }
        }
        
        if(numPeopleTarget != 0){
            System.out.println("the number of people who reache the target is: " + numPeopleTarget);
            for (int i = 0; i < peopleTarget.length; i++){
                if( i != 0 && peopleTarget[i] == 0) break;
                else System.out.println("the person with the ID: " + (peopleTarget[i]+1) +" his sales is: " + sales[peopleTarget[i]]);
            }
        } else {
            System.out.println("there are no sales people reached that target.");
        }
    }
}
