package Lab1;

import java.util.Scanner;
public class GradingQuizzes {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter how many question ar in the quiz: ");
        int Q = input.nextInt();
        int[] QList = new int[Q];
        
        //we will loop over the number of question
        //to ask the user of the answers sheet
        //then store in an array
        System.out.println("please enter the answers for each qusetion");
        for (int i = 0; i < Q; i++) {
            QList[i] = input.nextInt();
        }
        
        while(true){
            System.out.println("please enter the student answers: ");
            System.out.println("NOTE: please enter " + Q + " answers");
            System.out.println("to match the qusetions number:");
            
            int grade = 0;
            for (int i = 0; i < Q; i++) {
                int a = input.nextInt();
                if(a == QList[i]) grade++;
            }
            
            //we will print the grade with the percantage
            System.out.println("the grade for this student is: " + grade + " of " + Q);
            System.out.println("and the percentage is: " + (( (double)grade/Q) *100) + "% \n");
            
            //here we will ask the user if he wants to grade another answer sheet
            System.out.println("want to quit? \"enter N\" or continue to grade another student");
            char choice = input.next().toUpperCase().charAt(0);    
            if(choice == 'N') break;
        }
        
    }
}
