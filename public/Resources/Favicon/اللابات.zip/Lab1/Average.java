package Lab1;

import static java.lang.Integer.parseInt;

public class Average {
    public static void main(String[] args) {
        int sum = 0;
        if(args.length == 0)
            System.out.println("No arguments");
        else {
            for (int i = 0; i < args.length; i++) {
                sum += parseInt(args[i]);
            }
            System.out.println("the average is: " + sum/args.length);
        }
    }
}
