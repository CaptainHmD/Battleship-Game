package Lab1;


import java.text.NumberFormat;
import java.util.Scanner;

public class ShoppingCart {

    public int capacity;
    public int itemCount;	// total number of items in the cart private double totalPrice; // total price of items in the cart private int capacity;	// current cart capacity
    public double totalPrice;
    public Item[] cart;
//
// Creates an empty shopping cart with a capacity of 5 items.
//

    public ShoppingCart() {
        capacity = 5;
        itemCount = 0;
        totalPrice = 0.0;
        cart = new Item[capacity];
    }

//
// Adds an item to the shopping cart.
//
    public void addToCart(String itemName, double price, int quantity) {
        if (cart.length == itemCount) {
            increaseSize();
        }
        cart[itemCount] = new Item(itemName, price, quantity);
        totalPrice += price * quantity;
        itemCount++;
    }

//
// Returns the contents of the cart together with
// summary information.
//
    @Override
    public String toString() {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();

        String contents = "\nShopping Cart\n";
        contents += "\nItem\t\tUnit Price\tQuantity\tTotal\n";

        for (int i = 0; i < itemCount; i++) {
            contents += cart[i].toString() + "\n";
        }

        contents += "\nTotal Price: " + fmt.format(totalPrice);
        contents += "\n";

        return contents;
    }

//
//	Increases the capacity of the shopping cart by 3
//
    private void increaseSize() {
        Item[] temp = new Item[cart.length + 3];
        for (int i = 0; i < cart.length; i++) {
            temp[i] = cart[i];
        }
        cart = temp;
        capacity += 3;
    }

    public static void main(String[] args) {
        printMenu();
        Scanner scan = new Scanner(System.in);
        ShoppingCart invoice = new ShoppingCart();
        int choice = scan.nextInt();
        while (choice != 0) {
            
        int quantity;
        switch (choice) {
            case 1:
                System.out.println("How many of it you want?");
                quantity = scan.nextInt();
                invoice.addToCart("box of candy", 15,quantity );
                System.out.println(invoice);
                break;
            case 2:
                System.out.println("How many of it you want?");
                quantity = scan.nextInt();
                invoice.addToCart("family pepsi", 9,quantity );
                System.out.println(invoice);
                break;
            case 3:
                System.out.println("How many of it you want?");
                quantity = scan.nextInt();
                invoice.addToCart("can of ramen", 5,quantity );
                System.out.println(invoice);
                break;
            case 4:
                System.out.println("How many of it you want?");
                quantity = scan.nextInt();
                invoice.addToCart("cheese cake", 2,quantity );
                System.out.println(invoice);
                break;
            case 5:
                System.out.println("How many of it you want?");
                quantity = scan.nextInt();
                invoice.addToCart("pack of gum", 1,quantity );
                System.out.println(invoice);
                break;
            default:
                System.out.println("Sorry, invalid choice");
                System.out.println("Try again!!");
        }
        
        
            printMenu();
            choice = scan.nextInt();
        }
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        System.out.println("please pay : " + fmt.format(invoice.totalPrice));
    }


    public static void printMenu() {
        System.out.println("==welcome to our shop==");
        System.out.println("please pick what you want to add to the cart from the menu:");
        System.out.println("0: pay at the cashier");
        System.out.println("1: box of candy\t 15SR");
        System.out.println("2: family pepsi\t 9SR");
        System.out.println("3: can of ramen\t 5SR");
        System.out.println("4: cheese cake\t 2SR");
        System.out.println("5: pack of gum\t 1SR");
        System.out.print("\nEnter your choice: ");
    }
}
