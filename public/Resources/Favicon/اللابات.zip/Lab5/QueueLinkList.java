package Lab5;

class QueueLinkList {

    private LinkList list;
    private int nElems;
//--------------------------------------------------------------

    public QueueLinkList() {         // constructor
        list = new LinkList();
    }
//--------------------------------------------------------------

    public QueueLinkList(Node n) {         // constructor
       list = new LinkList(n);
    }
//--------------------------------------------------------------

    public void enQueue(int number) {    // put item in the queue
        Node n = new Node(number);
        list.insertLast(n);
    }
//--------------------------------------------------------------

    public Node deQueue() {         // take the next item from the queue
        if (isEmpty()) {
            System.out.println("there are no elemnts in the queue");
            return null;
        }
        Node result = list.deleteFirst();
        return result;
    }
//--------------------------------------------------------------

    public Node peek() {         // peek at next elemnt in the ququq
        return list.getFirst();
    }
        public void dispay() {    // display the content of the queue
        list.displayList();
    }
//--------------------------------------------------------------

    public boolean isEmpty() {    // true if queue is empty
        return list.isEmpty();
    }
//--------------------------------------------------------------

}
