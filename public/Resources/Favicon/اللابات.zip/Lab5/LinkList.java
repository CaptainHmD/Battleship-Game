package Lab5;

class LinkList {

    private Node first;                            	  // ref to first item on list
    private int nElems;

    public Node getFirst() // get value of first
    {
        return first;
    }

    public LinkList() // constructor
    {
        first = null;
        nElems = 0;
    }                           	  // no items on list yet

    public LinkList(Node f) {
        first = f;
        nElems = 1;
    }

    public boolean isEmpty() // true if list is empty
    {
        return (first == null);
    }

    public void insertFirst(Node n) {              	 // insert at start of list
        if (isEmpty()) {
            first = n;
        } else {

            n.setNext(first);       				 // newLink --> old first
            first = n;           				  // first --> newLink
        }
        nElems++;
    }

    public void insertLast(Node n) {	// insert at start of list
        Node current = first;
        if (first == null) {
            first = n;
            return;
        }
        while (current.getNext() != null) {
            current = current.getNext();
        }
        current.setNext(n);
        nElems++;
    }// end insertLast
    
    public Node get(int index) {
        Node node = first;
        int counter = 0;

        while (node != null) {
            if (counter == index) {
                return node;
            }
            counter++;
            node = node.getNext();
        }

        return null;
    }


    public void insert(int index, Node n) {
        if(index == 0){
            insertFirst(n);
        } else if(index == nElems){
            insertLast(n);
        }
        Node node = first;
        int counter = 0;

        while (node != null) {
            if (counter + 1  == index) {
                n.setNext(node.getNext());
                node.setNext(n);
            }
            counter++;
            node = node.getNext();
        }
    }
    

    public Node deleteFirst() {      // delete first item 
        if (this.isEmpty()) {
            return null;
        }
        Node n = first;          // save reference to link
        first = first.getNext();         // delete it: first-->old getNext()
        n.setNext(null);
        nElems--;
        return n;          // return deleted link
    }
// -------------------------------------------------------------
//    public ListIterator getIterator() { // return iterator
//        return new ListIterator(this);  // initialized with
//    }                               //    this list
// -------------------------------------------------------------

    public void displayList() {
        System.out.println(this.toString());
    }

    public String toString() {
        String s = "[";
        Node p = first;       // start at beginning of list
        while (p != null) {     // until end of list,
            s = s + p.toString();   // print data
            if (p.getNext() != null) {
                s += " ";
            }
            p = p.getNext();  // move to getNext() link
        }
        s = s + "]";
        return s;
    }
// -------------------------------------------------------------

    public Node find(int key) {
        Node p = first;
        while (p != null) {
            if (p.getData() == key) {
                return p;
            }//if
            p = p.getNext();
        }// while
        return null;
    }

    public int indexOf(Node n) {
        Node p = first;
        int c = -1;
        while (p != null) {
            c++;
            if (p.getData() == n.getData()) {
                return c;
            }//if
            p = p.getNext();

        }// while

        return -1;
    }

    public Node delete(int key) {
        if (this.isEmpty()) {
            return null;
        }

        Node prev = first;
        Node current = first.getNext();
        if (first.getNext() == null & first.getData() == key) {
            first = null;
            return current;
        }

        if (first.getData() == key) {
            first = first.getNext();
            return prev;
        }

        while (current != null) {
            if (current.getData() == key) {
                prev.setNext(current.getNext());
                current.setNext(null);
                nElems--;
                return current;
            }//if

            prev = current;
            current = current.getNext();

        }// while
        return null;
    }

    public Node deleteLast() {
        if (this.isEmpty()) {
            return null;
        }
        Node p = first;
        Node pre = null;
        while (p.getNext() != null) {
            pre = p;
            p = p.getNext();
        }// end while
        if (pre == null) {
            first = null;
            return p;
        }
        nElems--;
        pre.setNext(null);
        return p;
    }// end deleteLast

    public int sum() {
        Node p = first;
        int sum = 0;
        while (p != null) {
            sum += p.getData();
            p = p.getNext();
        }// while
        return sum;
    }

    public double avg() {
        double avg = (double) this.sum() / this.nElems;
        return avg;
    }

    public boolean isOrdered() {
        if (first == null | first.getNext() == null) {
            return true;
        }

        Node n = first;
        while (n.getNext() != null) {
            if (n.getData() > n.getNext().getData()) {
                return false;
            }
            n = n.getNext();
        }
        return true;
    }

    public boolean isUnique() {
        if (first.getNext() == null) {
            return true;
        }

        Node outNode = first;
        Node inNode;
        while (outNode != null) {
            inNode = outNode.getNext();
            while (inNode != null) {
                if (inNode.getData() == outNode.getData()) {
                    return false;
                }
                inNode = inNode.getNext();
            }
            outNode = outNode.getNext();
        }
        return true;
    }

    public int max() {
        Node p = first;
        int max = 0;
        while (p != null) {
            if (p.getData() > max) {
                max = p.getData();
            }
            p = p.getNext();
        }// while
        return max;
    }

    public int min() {
        if (first == null) {
            return 0;
        }
        if (first.getNext() == null) {
            return first.getData();
        }
        Node p = first.getNext();
        int min = first.getData();
        while (p != null) {
            if (p.getData() < min) {
                min = p.getData();
            }
            p = p.getNext();
        }// while
        return min;
    }

    public int range() {
        return (this.max() - this.min());
    }

    public void removeDublicates() {
        Node outNode = first;
        Node inNode;
        while (outNode != null) {
            inNode = outNode.getNext();
            while (inNode != null) {
                if (inNode.getData() == outNode.getData()) {
                    this.delete(inNode.getData());
                }
                inNode = inNode.getNext();
            }
            outNode = outNode.getNext();
        }
    }

   
    public int length() {
        return nElems;
    }

}  // end class LinkList
