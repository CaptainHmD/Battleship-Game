package Lab5;

/**
 *
 * @author aahba
 */
public class CircularDoubleLinked {

    private DoubleNode first;
    private DoubleNode last;
    private int nElems;

    public CircularDoubleLinked() {
    }

    public CircularDoubleLinked(DoubleNode first) {
        this.first = first;
        nElems = 1;
    }

    public void insertFirst(DoubleNode n) {              	 // insert at start of list
        if (isEmpty()) {
            first = n;
            last = n;
            first.setNext(last);
            first.setPrevious(last);
            last.setNext(first);
            last.setPrevious(first);
        } else {
            first.setPrevious(n);
            n.setNext(first); 
            n.setPrevious(last);
            first = n;     
        }
        nElems++;
    }

    public void insertLast(DoubleNode n) {	// insert at start of list
        if (isEmpty()) {
            first = n;
            last = n;
            first.setNext(n);
            first.setPrevious(n);
            last.setNext(n);
            last.setPrevious(n);
        } else {
            last.setNext(n);
            n.setNext(first);
            n.setPrevious(last);
            last = n;
        }
        nElems++;
    }// end insertLast
    
    public void display(){
        DoubleNode node = first;
        System.out.print("[");
        for (int i = 0; i < nElems; i++) {
            System.out.print(node.getData());
            if(i != nElems - 1){
                System.out.print(" ");
            }
            node = node.getNext();
        }
        System.out.println("]");
    }
    
    public void insertAt(int index, DoubleNode newNode){
        if(index < 0 | index > nElems){
            System.out.println("invalid insert index");
            return;
        }
        DoubleNode current;
        if(index < (nElems/2)){
            current = first;
            int i;
            for(i = 0; i != index; i--) {
                current = current.getNext();
            }
            insertAfterNode(current, newNode);
        } else {
            current = last;
            int i;
            for(i = nElems; i != index; i--) {
                current = current.getPrevious();
            }
            insertAfterNode(current, newNode);
        }
        nElems++;
    }
    
    private void insertAfterNode(DoubleNode listNode,DoubleNode newNode){
        DoubleNode nextNode = listNode.getNext();
        
        newNode.setNext(listNode.getNext());
        newNode.setPrevious(listNode);
        
        listNode.setNext(newNode);
        nextNode.setPrevious(newNode);
    }
    
    public DoubleNode deleteFirst(){
        DoubleNode result = first;
        DoubleNode second = first.getNext();
        
        second.setPrevious(last);
        last.setNext(second);
        first = second;
        
        result.setNext(null);
        result.setPrevious(null);
        nElems--;
        return result;
    }
    
    public DoubleNode deleteLast(){
        DoubleNode result = last;
        DoubleNode secondToLast = last.getPrevious();
        
        secondToLast.setNext(first);
        first.setPrevious(secondToLast);
        last = secondToLast;
        
        result.setNext(null);
        result.setPrevious(null);
        nElems--;
        return result;
    }
    
    public DoubleNode deleteNode(int key){
        DoubleNode result = find(key);
        if(result== null){
            return null;
        }else {
            deleteNode(result);
        }
        nElems--;
        return result;
    }
    
    private void deleteNode(DoubleNode node){
        DoubleNode prevoius = node.getPrevious();
        DoubleNode next = node.getNext();
        
        prevoius.setNext(next);
        next.setPrevious(prevoius);
        
        node.setNext(null);
        node.setPrevious(null);
    }
    
    public DoubleNode find(int key){
        DoubleNode current = first;
        
        for (int i = 0; i < nElems; i++){
            if(current.getData() == key){
                return current;
            }
            current = current.getNext();
        }
        return null;
    }
    
    public int indexOf(int key){
        DoubleNode current = first;
        
        for (int i = 0; i < nElems; i++){
            if(current.getData() == key){
                return i;
            }
            current = current.getNext();
        }
        return -1;
    }
    
    
    public boolean isEmpty() {
        return first == null;
    }

    public DoubleNode getFirst() {
        return first;
    }

    public DoubleNode getLast() {
        return last;
    }
    
    

}
