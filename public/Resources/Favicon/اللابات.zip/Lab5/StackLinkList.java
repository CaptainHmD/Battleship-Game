package Lab5;

class StackLinkList {

    private LinkList list;   
 //--------------------------------------------------------------

    public StackLinkList() {         // constructor
        list = new LinkList();
    }
//--------------------------------------------------------------

    public StackLinkList(Node n) {         // constructor
        list = new LinkList(n);           
    }
//--------------------------------------------------------------

    public void push(int j) {    // put item on top of stack
        Node n = new Node(j);
        list.insertFirst(n);
    }
//--------------------------------------------------------------

    public Node pop() {         // take item from top of stack
        if (list.isEmpty()) {
            System.out.println("there are no elemnts in the stack");
            return null;
        }
        Node result = list.deleteFirst();
        return result;
    }
//--------------------------------------------------------------

    public Node peek() {         // peek at top of stack
        return list.getFirst();
    }
//--------------------------------------------------------------

    public void dispay() {    // display the content of the stack
        list.displayList();
    }
//--------------------------------------------------------------
    

    public boolean isEmpty() {    // true if stack is empty
        return list.isEmpty();
    }
//--------------------------------------------------------------

}
