package Lab5;

/**
 *
 * @author aahba
 */
public class CircularDoubleLinkedApp {
    public static void main(String[] args) {
        CircularDoubleLinked list = new CircularDoubleLinked();
        list.insertLast(new DoubleNode(1));
        list.insertLast(new DoubleNode(2));
        list.insertLast(new DoubleNode(3));
        list.insertLast(new DoubleNode(4));
        list.insertLast(new DoubleNode(5));
        System.out.print("the original list: ");
        list.display();
        
        System.out.print("the list after inserting a node in index 2 that hhave the data 10: ");
        list.insertAt(2, new DoubleNode(10));
        list.display();
        
        System.out.print("the list after delting the last node: ");
        list.deleteLast();
        list.display();
        
        System.out.println("the list after deleting the node with data 10: ");
        list.deleteNode(10);
        list.display();

    }
}
