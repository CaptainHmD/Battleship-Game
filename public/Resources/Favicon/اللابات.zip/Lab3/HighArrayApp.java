package Lab3;

public class HighArrayApp {

    public static void main(String[] args) {
        HighArrayDynamic list = new HighArrayDynamic(10);

        //insert items to the array
        list.insert(1);
        list.insert(7);
        list.insert(2);
        list.insert(5);
        list.insert(4);
        list.insert(3);
        list.insert(8);
        list.insert(6);
        list.insert(9);
        list.insert(2);
        //then display it
        System.out.println("the array");
        list.display();

        //now we will add 0 to the first of the array
        System.out.println("\nadd first");
        list.addFirst(0);
        list.display();

        //removing the first elemnt of the array
        System.out.println("\nremove first");
        list.removeFirst();
//        System.out.println(list.a.length);
//        list.removeFirst();
//        System.out.println(list.a.length);
//        list.removeFirst();
//        System.out.println(list.a.length);
        list.display();

        //adding an elemment th specfic index
        System.out.println("\nadd to index");
        list.addAt(5, 0);
        list.display();

        //removing an element in specific index
        System.out.println("\nremove at");
        list.removeAt(5);
        list.display();

        //copying the list to external variable
        System.out.println("\ncopying list to externla variable");
        long[] listCopy = list.toArray();
        for (int i = 0; i < listCopy.length; i++) {
            System.out.print(listCopy[i] + " ");
        }
        System.out.println("");

        //setting an index to be specific value
        System.out.println("\nset an index to specific value");
        list.set(2, 10);
        list.display();

        //getting the value of specific index
        System.out.println("\ngeeting the value of specific index");
        long value = list.get(9);
        System.out.println("the value of index 9 in the list is " + value);

        //clearing the list
//        System.out.println("\nclearing the list");
//        list.clear();
        list.display();

        System.out.println("after sorting: ");
        list.insertionSort();
        list.display();
    }
}
